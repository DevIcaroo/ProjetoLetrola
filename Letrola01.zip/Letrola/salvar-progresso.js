async function salvarProgresso(jogador, fase, estrelas = 0) {
  const res = await fetch('/salvar-progresso', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      id_jogador: jogador,
      fase: fase,
      estrelas: estrelas
    })
  });

  const data = await res.json();
  console.log(data.message);
}
