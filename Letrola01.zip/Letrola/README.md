# 🎓 Projeto Letrola - Backend

Este é o back-end do projeto **Letrola**, um jogo sério voltado para a **alfabetização de crianças**. Ele foi desenvolvido usando **Node.js**, **Express** e **SQLite**.

---------------------------------------------------------------------------------------------------------------------

## 🚀 Tecnologias utilizadas

- Node.js
- Express (npm install express)
- SQLite (via sqlite3) (npm install sqlite3)
- Postman (para testes de back-end)

---------------------------------------------------------------------------------------------------------------------

## ⚙️ Como rodar o projeto

### 1. Clonar o repositório ou descompactar o .zip.
### 2. Instalar dependencias (npm install express), (npm install sqlite3).
### 3. Iniciar o servidor (node server.js).

---------------------------------------------------------------------------------------------------------------------

## 🗃️ Estrutura do banco de dados (SQLite)

### A tabela usada é chamada progresso:

### | Campo       | Tipo      | Descrição                        |
    | ----------- | --------- | -------------------------------- |
    | id          | INTEGER   | Chave primária autoincrementável |
    | id_jogador  | TEXT      | Identificador do jogador         |
    | fase        | INTEGER   | Número da fase concluída         |
    | data        | TIMESTAMP | Data/hora em que foi salva       |

---------------------------------------------------------------------------------------------------------------------

## 📌 Endpoints disponíveis

### 🔹 POST /salvar-progresso
    Salva a fase concluída por um jogador.    
### Body (JSON):
    {
    "id_jogador": "jogador1",
    "fase": 1,
    "estrelas": 3
    }
### Resposta:
    {
    "message": "Progresso salvo com sucesso.",
     "id": 1
    }


### 🔹 GET /progresso/:id_jogador
    Retorna a fase máxima alcançada por um jogador.
### Exemplo:
    GET http://localhost:3000/progresso/jogador1   
### Resposta:
    {
    "fase_atual": 1
    }


### 🔹 GET /fase/:id_jogador/:fase
    Verifica se o jogador pode acessar uma fase específica.
### Exemplo:
    GET http://localhost:3000/fase/jogador1/2
### Resposta (Permitido):
    {
    "permitido": true,
    "mensagem": "Acesso liberado para a fase 2."
    }
### Resposta (Negado):
    {
    "permitido": false,
    "mensagem": "Fase 2 bloqueada. Conclua a fase 1 primeiro."
    }


### 🔹 GET /estrelas/:id_jogador/:fase
    Consulta as estrelas de uma fase
### Exemplo:
    GET http://localhost:3000/estrelas/jogador1/1
### Resposta:
    {
    "estrelas": 3
    }
    
---------------------------------------------------------------------------------------------------------------------

### ✅ Funcionalidades principais
    Salvar progresso do jogador.

    Controlar acesso às fases com base no progresso.

    Consultar estrelas da fase.

    Banco de dados local (sem login necessário).

    Respostas claras para integração com front-end.

--------------------------------------------------------------------------------------------------------------------    