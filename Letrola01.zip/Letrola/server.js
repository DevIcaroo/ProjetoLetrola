// server.js
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware para aceitar JSON
app.use(express.json());

// Criar/abrir o banco de dados
const dbPath = path.resolve(__dirname, 'progresso.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Erro ao abrir banco de dados:', err.message);
  } else {
    console.log('Banco de dados conectado com sucesso.');
  }
});

// Criar a tabela 'progresso' se não existir
db.run(`
  CREATE TABLE IF NOT EXISTS progresso (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_jogador TEXT NOT NULL,
  fase INTEGER NOT NULL,
  estrelas INTEGER DEFAULT 0,
  data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
`);

// Criar a tabela 'personagens' se não existir
db.run(`
  CREATE TABLE IF NOT EXISTS personagens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL
)
`);

// Criar a tabela 'dialogos' se não existir
db.run(`
  CREATE TABLE IF NOT EXISTS dialogos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fase INTEGER NOT NULL,
  ordem INTEGER NOT NULL,
  personagem_id INTEGER NOT NULL,
  fala TEXT NOT NULL,
  expressao TEXT,
  FOREIGN KEY (personagem_id) REFERENCES personagens(id)
)
`);

// Rota para salvar o progresso
app.post('/salvar-progresso', (req, res) => {
  const { id_jogador, fase, estrelas } = req.body;

  if (!id_jogador || typeof fase !== 'number') {
    return res.status(400).json({ error: 'Dados inválidos.' });
  }

  const estrelasValidadas = Math.max(0, Math.min(estrelas ?? 0, 3)); // Garante entre 0 e 3

  db.run(
    `INSERT INTO progresso (id_jogador, fase, estrelas) VALUES (?, ?, ?)`,
    [id_jogador, fase, estrelasValidadas],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Erro ao salvar progresso.' });
      }
      res.json({ message: 'Progresso salvo com sucesso.', id: this.lastID });
    }
  );
});


// Rota para buscar o progresso atual do jogador
app.get('/progresso/:id_jogador', (req, res) => {
  const { id_jogador } = req.params;

  db.get(
    `SELECT MAX(fase) as fase_atual FROM progresso WHERE id_jogador = ?`,
    [id_jogador],
    (err, row) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Erro ao buscar progresso.' });
      }

      res.json({ fase_atual: row.fase_atual || 0 });
    }
  );
});

// Rota para verificar se o jogador pode acessar determinada fase
app.get('/fase/:id_jogador/:fase', (req, res) => {
  const { id_jogador, fase } = req.params;
  const faseRequisitada = parseInt(fase);

  db.get(
    `SELECT MAX(fase) as fase_atual FROM progresso WHERE id_jogador = ?`,
    [id_jogador],
    (err, row) => {
      if (err) {
        return res.status(500).json({ error: 'Erro ao buscar progresso.' });
      }

      const faseAtual = row.fase_atual || 0;

      if (faseRequisitada > faseAtual + 1) {
        return res.status(403).json({
          permitido: false,
          mensagem: `Fase ${faseRequisitada} bloqueada. Conclua a fase ${faseAtual + 1} primeiro.`,
        });
      }

      res.json({
        permitido: true,
        mensagem: `Acesso liberado para a fase ${faseRequisitada}.`,
      });
    }
  );
});

// Rota para consultar estrelas de uma fase
app.get('/estrelas/:id_jogador/:fase', (req, res) => {
  const { id_jogador, fase } = req.params;

  db.get(
    `SELECT estrelas FROM progresso WHERE id_jogador = ? AND fase = ? ORDER BY data DESC LIMIT 1`,
    [id_jogador, fase],
    (err, row) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Erro ao buscar estrelas.' });
      }

      if (!row) {
        return res.status(404).json({ estrelas: 0 });
      }

      res.json({ estrelas: row.estrelas });
    }
  );
});

// Rota para buscar dialogos de uma fase
app.get('/dialogos/:fase', (req, res) => {
  const fase = parseInt(req.params.fase);

  db.all(
    `SELECT d.ordem, p.nome AS personagem, d.fala, d.expressao
     FROM dialogos d
     JOIN personagens p ON d.personagem_id = p.id
     WHERE d.fase = ?
     ORDER BY d.ordem ASC`,
    [fase],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Erro ao buscar diálogos.' });
      }
      res.json(rows);
    }
  );
});


// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
