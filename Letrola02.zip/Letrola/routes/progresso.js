const express = require('express');
const router = express.Router();
const db = require('../db');

function validarIdJogador(id) {
  return /^[a-zA-Z0-9_-]{3,20}$/.test(id);
}

router.post('/salvar-progresso', (req, res) => {
  const { id_jogador, fase, estrelas } = req.body;

  if (
    !validarIdJogador(id_jogador) ||
    typeof fase !== 'number' ||
    fase < 1 ||
    (estrelas !== undefined && (typeof estrelas !== 'number' || estrelas < 0 || estrelas > 3))
  ) {
    return res.status(400).json({ error: 'Dados inválidos.' });
  }

  const estrelasValidadas = Math.max(0, Math.min(estrelas ?? 0, 3));

  db.get(
    `SELECT * FROM progresso WHERE id_jogador = ? AND fase = ?`,
    [id_jogador, fase],
    (err, row) => {
      if (err) {
        console.error('Erro ao acessar o banco:', err);
        return res.status(500).json({ error: 'Erro ao acessar o banco.' });
      }

      if (row) {
        db.run(
          `UPDATE progresso SET estrelas = ?, data = CURRENT_TIMESTAMP WHERE id_jogador = ? AND fase = ?`,
          [estrelasValidadas, id_jogador, fase],
          function (err) {
            if (err) {
              console.error('Erro ao atualizar progresso:', err);
              return res.status(500).json({ error: 'Erro ao atualizar progresso.' });
            }
            return res.json({ message: 'Progresso atualizado com sucesso.' });
          }
        );
      } else {
        db.run(
          `INSERT INTO progresso (id_jogador, fase, estrelas) VALUES (?, ?, ?)`,
          [id_jogador, fase, estrelasValidadas],
          function (err) {
            if (err) {
              console.error('Erro ao salvar progresso:', err);
              return res.status(500).json({ error: 'Erro ao salvar progresso.' });
            }
            return res.status(201).json({ message: 'Progresso salvo com sucesso.', id: this.lastID });
          }
        );
      }
    }
  );
});

router.get('/progresso/:id_jogador', (req, res) => {
  const { id_jogador } = req.params;

  if (!validarIdJogador(id_jogador)) {
    return res.status(400).json({ error: 'ID do jogador inválido.' });
  }

  db.get(
    `SELECT MAX(fase) as fase_atual FROM progresso WHERE id_jogador = ?`,
    [id_jogador],
    (err, row) => {
      if (err) {
        console.error('Erro ao buscar progresso:', err);
        return res.status(500).json({ error: 'Erro ao buscar progresso.' });
      }
      if (!row) {
        return res.status(404).json({ message: 'Nenhum progresso encontrado para esse jogador.' });
      }
      res.json({ fase_atual: row.fase_atual || 0 });
    }
  );
});

router.get('/estrelas/:id_jogador/:fase', (req, res) => {
  const { id_jogador, fase } = req.params;
  const faseNum = parseInt(fase);

  if (!validarIdJogador(id_jogador) || isNaN(faseNum) || faseNum < 1) {
    return res.status(400).json({ error: 'Parâmetros inválidos.' });
  }

  db.get(
    `SELECT estrelas FROM progresso WHERE id_jogador = ? AND fase = ? ORDER BY data DESC LIMIT 1`,
    [id_jogador, faseNum],
    (err, row) => {
      if (err) {
        console.error('Erro ao buscar estrelas:', err);
        return res.status(500).json({ error: 'Erro ao buscar estrelas.' });
      }
      if (!row) {
        return res.json({ estrelas: 0 }); // Pode ser 404, mas aqui preferi responder 0
      }
      res.json({ estrelas: row.estrelas });
    }
  );
});

module.exports = router;
