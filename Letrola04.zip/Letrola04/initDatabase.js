const db = require('./db');

function criarTabelas() {
  db.serialize(() => {

    // Tabela Progresso
    db.run(`
      CREATE TABLE IF NOT EXISTS progresso (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_jogador TEXT NOT NULL,
        fase INTEGER NOT NULL,
        estrelas INTEGER DEFAULT 0,
        tempo_gasto INTEGER,
        data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Tabela Personagens
    db.run(`
      CREATE TABLE IF NOT EXISTS personagens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL
      )
    `);

    // Tabela Fases
    db.run(`
      CREATE TABLE IF NOT EXISTS fases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        descricao TEXT,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Tabela Dialogos
    db.run(`
      CREATE TABLE IF NOT EXISTS dialogos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fase INTEGER NOT NULL,
        ordem INTEGER NOT NULL,
        personagem_id INTEGER NOT NULL,
        fala TEXT NOT NULL,
        expressao TEXT,
        FOREIGN KEY (personagem_id) REFERENCES personagens(id)
      )
    `);

    // Tabela Itens Fase
    db.run(`
      CREATE TABLE IF NOT EXISTS itens_fase (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fase_id INTEGER NOT NULL,
        ordem INTEGER NOT NULL,
        resposta TEXT NOT NULL,
        letras TEXT NOT NULL,
        dica1 TEXT,
        dica2 TEXT,
        imagem_url TEXT,
        FOREIGN KEY (fase_id) REFERENCES fases(id)
      )
    `);

    console.log('Tabelas criadas/verificadas com sucesso.');
  });
}

module.exports = criarTabelas;