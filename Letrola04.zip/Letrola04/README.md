🎓 Projeto Letrola - Backend

Este é o back-end do projeto Letrola, um jogo sério voltado para a alfabetização de crianças. Desenvolvido com Node.js, Express e SQLite para armazenar progresso, diálogos, fases e itens das fases.

------------------------------------------------------------------------------------------------------------------------------------------------------------

🚀 Tecnologias utilizadas

Node.js

Express (npm install express)

SQLite (npm install sqlite3)

Postman (para testes do backend)

------------------------------------------------------------------------------------------------------------------------------------------------------------

⚙️ Como rodar o projeto

Clone o repositório ou descompacte o arquivo .zip.

Instale as dependências:

npm install express sqlite3


Inicie o servidor:

node server.js


O backend estará disponível em http://localhost:3000

------------------------------------------------------------------------------------------------------------------------------------------------------------

🗃️ Estrutura do banco de dados (SQLite)
Tabelas principais:
Tabela	Descrição
progresso	Armazena progresso e estrelas do jogador por fase
personagens	Personagens do jogo (ex: Letrola)
dialogos	Falas dos personagens por fase
itens_fase	Itens da fase: imagens, respostas, letras e dicas

📌 Endpoints disponíveis
1. Salvar ou atualizar progresso

POST /salvar-progresso
Body (JSON):

{
  "id_jogador": "jogador1",
  "fase": 1,
  "estrelas": 3
}


Resposta:

{
  "message": "Progresso salvo com sucesso.",
  "id": 1
}


2. Obter fase atual do jogador

GET /progresso/:id_jogador
Exemplo:
GET http://localhost:3000/progresso/jogador1
Resposta:

{
  "fase_atual": 1
}


3. Verificar acesso a uma fase

GET /fase/:id_jogador/:fase
Exemplo:
GET http://localhost:3000/fase/jogador1/2
Resposta (permitido):

{
  "permitido": true,
  "mensagem": "Acesso liberado para a fase 2."
}


Resposta (bloqueado):

{
  "permitido": false,
  "mensagem": "Fase 2 bloqueada. Conclua a fase 1 primeiro."
}


4. Consultar estrelas de uma fase

GET /estrelas/:id_jogador/:fase
Exemplo:
GET http://localhost:3000/estrelas/jogador1/1
Resposta:

{
  "estrelas": 3
}


5. Buscar diálogos de uma fase

GET /dialogos/:fase
Exemplo:
GET http://localhost:3000/dialogos/1
Resposta:

[
  {
    "ordem": 1,
    "personagem": "Letrola",
    "fala": "Vamos começar!",
    "expressao": "feliz"
  },
  ...
]


6. Buscar itens da fase (imagens, letras, dicas)

GET /itens-fase/:fase_id
Exemplo:
GET http://localhost:3000/itens-fase/1
Resposta:

[
  {
    "id": 1,
    "fase_id": 1,
    "ordem": 1,
    "resposta": "bola",
    "letras": ["b", "o", "l", "a", "x", "m"],  // Array de letras disponíveis para formar a palavra
    "dica1": "É redonda",
    "dica2": "Usamos para jogar futebol",
    "imagem_url": "http://exemplo.com/bola.png"
  },
  ...
]


✅ Funcionalidades principais

Salvar e atualizar o progresso do jogador, garantindo que ele não pule fases.

Controlar o acesso às fases baseado no progresso.

Consultar a quantidade de estrelas conquistadas em cada fase.

Fornecer diálogos para personagens guiarem a criança durante o jogo.

Disponibilizar os itens de cada fase com suas imagens, respostas, letras para formar a palavra, e dicas para ajudar a criança.

Banco de dados local, simples, sem necessidade de login.

APIs pensadas para fácil integração com o frontend.