const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/:fase_id', (req, res) => {
  const faseId = parseInt(req.params.fase_id);

  if (isNaN(faseId) || faseId < 1) {
    return res.status(400).json({ error: 'ID da fase inválido.' });
  }

  db.all(
    `SELECT * FROM itens_fase WHERE fase_id = ? ORDER BY ordem ASC`,
    [faseId],
    (err, rows) => {
      if (err) {
        console.error('Erro ao buscar itens da fase:', err);
        return res.status(500).json({ error: 'Erro ao buscar itens da fase.' });
      }

      if (!rows.length) {
        return res.status(404).json({ message: 'Nenhum item encontrado para essa fase.' });
      }

      const itens = rows.map(item => {
        let letrasParsed = [];
        try {
          letrasParsed = JSON.parse(item.letras);
        } catch (parseErr) {
          console.warn(`Falha ao parsear letras para item ID ${item.id}:`, parseErr);
        }
        return {
          ...item,
          letras: letrasParsed,
        };
      });

      res.json(itens);
    }
  );
});

module.exports = router;
